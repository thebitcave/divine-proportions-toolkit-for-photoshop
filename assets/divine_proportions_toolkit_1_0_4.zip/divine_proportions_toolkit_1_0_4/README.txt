Thanks for downloading this little utility for Photoshop CS6.

To install it, simply double click the .zxp package (you will need Adobe Extension Manager CS6).

Alternatively you can download it directly from Adobe Exchange: http://bit.ly/UorAAt

Restart Photoshop and open the panel by selecting: Window > Extensions > Divine Proportions Toolkit.

mail: thebitcave@gmail.com
web: thebitcave.com
twitter: thebitcave
